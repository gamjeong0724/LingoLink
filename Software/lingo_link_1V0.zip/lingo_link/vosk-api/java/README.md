Java bindings for Vosk API using jnr-ffi

See demo project for details, build it with Gradle.

Download model and unpack as "model" folder in the demo project.

Make sure you are using recent JDK and Gradle.
