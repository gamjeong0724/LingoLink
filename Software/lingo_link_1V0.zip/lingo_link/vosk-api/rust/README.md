See

https://github.com/Bear-03/vosk-rs

https://crates.io/crates/vosk
